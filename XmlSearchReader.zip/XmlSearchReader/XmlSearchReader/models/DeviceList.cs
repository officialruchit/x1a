﻿using System.Collections.Generic;
using System.Xml.Serialization;
namespace XmlSearchReader
{
    #region Public class
    [XmlRoot("Devices")]
    public class DeviceList
    {
        [XmlElement("Dev")]
        public List<Device> Devices { get; set; }
    }
    #endregion
}
