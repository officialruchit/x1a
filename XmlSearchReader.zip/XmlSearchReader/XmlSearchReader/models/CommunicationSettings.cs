﻿namespace XmlSearchReader
{
    public class CommunicationSettings
    {
        public string PortNo { get; set; }  // Change the data type to int
        public string UseSSL { get; set; } // Change the data type to bool
        public string Password { get; set; }
    }
}