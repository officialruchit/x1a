﻿using System.Xml.Serialization;
namespace XmlSearchReader
{
    #region Public class

    public class Device
    {
        [XmlAttribute("SrNo")]
        public string SrNo { get; set; }
        public string Address { get; set; }
        public string DevName { get; set; }
        public string ModelName { get; set; }
        public string Type { get; set; }
        public CommunicationSettings CommSetting { get; set; }
    }
    #endregion
}