﻿using System;
using System.Collections.Generic;
namespace XmlSearchReader
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Validate and get the XML file path from command line arguments
            string xmlFilePath = Utility.ValidateAndGetXmlFilePath(args);

            // If the XML file path is invalid or not provided, print error message and terminate
            if (xmlFilePath == null)
            {
                Console.WriteLine($"{Constant.ErrorMessage}");
            }

            // Check if the XML file specified by xmlFilePath exists
            bool CheckFileExistence = Utility.CheckFileExistence(xmlFilePath);

            // If the file does not exist, print a message indicating file not found
            if (CheckFileExistence == false)
            {
                Console.WriteLine($"{Constant.messageForFileNotExists}");
            }


            // Validate if the XML file specified by xmlFilePath has a valid file extension
            bool fileXmlFileValidation = Utility.ValidateXmlFileExtension(xmlFilePath);

            // If the file extension is invalid, print a message indicating an invalid file extension
            if (fileXmlFileValidation == false)
            {
                Console.WriteLine($"{Constant.MessageForInvalidFileExtension}");
            }

            /*   string errorMessage = XMlValidation.ErrorForXmlException(xmlFilePath, out Dictionary<string, Device> devicesDictionary);*/

            /*  if (string.IsNullOrEmpty(errorMessage) == false)
              {
                  Console.WriteLine(errorMessage);
              }*/
            /* if (string.IsNullOrEmpty(errorMessageee) == false)
             {
                 Console.WriteLine(errorMessageee);
             }*/



            //

            Dictionary<string, Device> deviceData = new Dictionary<string, Device>();
            List<string> validationMessage = XMlValidation.ValidateXml(xmlFilePath);

            if (validationMessage != null)
            {
                Console.WriteLine(validationMessage);

            }
            Dictionary<string, Device> data = XMlValidation.ReadXml(xmlFilePath);
            while (true)
            {
                Console.WriteLine(Constant.MessageForMenu());
                string choice = Console.ReadLine().Trim();
                switch (choice)
                {
                    case "1":
                        DeviceDisplayManager.ShowDevices(data);
                        break;
                    case "2":
                        Console.Write("Enter serial number of the device: ");
                        string serialNumber = Console.ReadLine().Trim();
                        DeviceDisplayManager.SearchDevice(data, serialNumber);
                        break;
                    case "3":
                        Console.WriteLine("Program terminated.");
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Error: Invalid input. Please choose from the above options.");
                        break;
                }
            }
        }
    }
}
