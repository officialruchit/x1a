﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml.Serialization;
namespace XmlSearchReader
{
    /// <summary>
    /// 
    /// </summary>
    public class XMlValidation
    {
        /*  public static string ErrorForXmlException(string xmlFilePath, out Dictionary<string, Device> devicesDictionary)
          {
              devicesDictionary = null;

              try
              {
                  devicesDictionary = ReadXml(xmlFilePath);
                  if (devicesDictionary.Count == 0)
                  {
                      return "Error: No devices found in the XML file.\nTerminate program.";
                  }

                  return null; // No error
              }
              catch (XmlException ex)
              {
                  *//*    errorMessage = null;*//*
                  return $"Error: Invalid XML format. {ex.Message}\nPlease check the XML file and fix the formatting issues.\nTerminate program.";
              }
              catch (Exception ex)
              {
                  *//*   errorMessage = null;*//*
                  return $"Error: An unexpected error occurred while parsing XML. {ex.Message}\nTerminate program.";
              }
          }*/

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static List<string> ValidateXml(string filePath)
        {
            List<string> validationMessages = new List<string>();
            int deviceIndex = 1;

            XmlSerializer serializer = new XmlSerializer(typeof(DeviceList));
            using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
            {
                DeviceList deviceList = (DeviceList)serializer.Deserialize(fileStream);

                foreach (var device in deviceList.Devices)
                {
                    StringBuilder result = new StringBuilder();
                    List<string> data = new List<string>();
                    result.AppendLine($"Device index:   {deviceIndex}");
                    result.AppendLine($"Serial Number:  {Utility.ValidateSrNo(device, data)}");
                    result.AppendLine($"IP Address:     {Utility.ValidateAddress(device, data)}");
                    result.AppendLine($"Device Name:    {Utility.ValidatedeviceName(device)}");
                    result.AppendLine($"Model Name:     {Utility.ValidateModelName(device)}");
                    result.AppendLine($"Type:           {Utility.Validatetype(device)}");
                    result.AppendLine($"Port Number:    {Utility.ValidatePortNo(device.CommSetting.PortNo)}");
                    result.AppendLine($"Use SSL:        {Utility.ValidateUseSSl(device)}");
                    result.AppendLine($"Password:       {Utility.ValidatePassword(device)}");
                    result.AppendLine();
                    if (HasError(result.ToString()))
                    {
                        validationMessages.Add(result.ToString());
                    }


                    deviceIndex++;
                }
            }
            if (validationMessages.Count > 0)
            {
                Console.WriteLine(validationMessages[0]);
            }

            // Return the device data dictionary only if all data is valid

            return null; ;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private static bool HasError(string message)
        {
            return message.Contains("(Duplicate)") || message.Contains("not present") || message.Contains("(empty)") || message.Contains("(Invalid length)") || message.Contains("(Not supported characters)") || message.Contains("(Not supported formate)");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static Dictionary<string, Device> ReadXml(string filePath)
        {
            XmlSerializer serialize = new XmlSerializer(typeof(DeviceList));
            using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
            {
                DeviceList deviceList = (DeviceList)serialize.Deserialize(fileStream);
                Dictionary<string, Device> devicesDictionary = new Dictionary<string, Device>();
                int deviceIndex = 1;
                foreach (var device in deviceList.Devices)
                {
                    devicesDictionary.Add($"Device{deviceIndex}", device);
                    deviceIndex++;
                }
                return devicesDictionary;
            }
        }
    }
}
