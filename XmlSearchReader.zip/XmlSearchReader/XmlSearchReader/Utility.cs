﻿using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
namespace XmlSearchReader
{
    public class Utility
    {
        /// <summary>
        /// Validates and retrieves the XML file path from command line arguments.
        /// </summary>
        /// <param name="args">The command line arguments passed to the program.</param>
        /// <returns>The XML file path if exactly one argument is provided; otherwise, returns null.</returns>
        public static string ValidateAndGetXmlFilePath(string[] args)
        {
            if (args.Length == 1)
            {
                return args[0];
            }
            else
            {
                return null; // or throw an exception based on your preference
            }
        }

        /// <summary>
        /// Checks if a file exists at the specified file path.
        /// </summary>
        /// <param name="filePath">The path to the file to be checked.</param>
        /// <returns>True if the file exists; otherwise, false.</returns>
        public static bool CheckFileExistence(string filePath)
        {
            if (File.Exists(filePath) == false)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Validates if the file extension of the specified XML file path is '.xml'.
        /// </summary>
        /// <param name="xmlFilePath">The path of the XML file to validate.</param>
        /// <returns>True if the file extension is '.xml'; otherwise, false.</returns>
        public static bool ValidateXmlFileExtension(string xmlFilePath)
        {
            if (Path.GetExtension(xmlFilePath).ToLower() != ".xml")
            {
                return false;
            }
            return true;
        }


        /// <summary>
        /// Checks if the input string contains any invalid characters.
        /// </summary>
        /// <param name="input">The string to be checked for invalid characters.</param>
        /// <returns>True if the input contains invalid characters, otherwise false.</returns>
        public static string ValidateSrNo(Device device, List<string> data)
        {
            if (device.SrNo == null)
            {
                return "(not present)";
            }
            if (string.IsNullOrEmpty(device.SrNo))
            {
                return "(empty)";
            }
            if (device.SrNo.Length > 16)
            {
                return "(Invalid length)";
            }
            if (Regex.IsMatch(device.SrNo, @"^[a-zA-Z0-9]+$") == false)
            {
                return "(Invalid characters)";
            }
            if (data.Contains(device.SrNo))
            {
                return "(Duplicate)";
            }
            else
            {
                data.Add(device.SrNo);
            }
            return device.SrNo;
        }

        /// <summary>
        /// Validates the IP address of the specified device.
        /// </summary>
        /// <param name="device">The device whose IP address is to be validated.</param>
        /// <param name="data">A list containing previously validated IP addresses to check for duplicates.</param>
        /// <returns>
        /// Returns "(not present)" if the IP address is null,
        /// "(empty)" if the IP address is empty,
        /// "(Invalid length)" if the IP address length exceeds 15 characters,
        /// "(Not supported format)" if the IP address format is not valid,
        /// "(Not supported characters)" if the IP address contains unsupported characters,
        /// "(Duplicate)" if the IP address is a duplicate of a previously validated IP address,
        /// otherwise returns the IP address.
        /// </returns>
        public static string ValidateAddress(Device device, List<string> data)
        {
            if (device.Address == null)
            {
                return "(not present)";
            }
            if (string.IsNullOrEmpty(device.Address))
            {
                return "(empty)";
            }
            if (device.Address.Length > 15)
            {
                return "(Invalid length)";
            }
            if (Regex.IsMatch(device.Address, @"^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$") == false)
            {
                return "(Not supported formate)";
            }
            if (Regex.IsMatch(device.Address, @"[^0-9\.]"))
            {
                return "(Not supported characters)";
            }
            if (data.Contains(device.Address))
            {
                return "(Duplicate)";
            }
            else
            {
                data.Add(device.Address);
            }
            return device.Address;
        }

        /// <summary>
        /// Validates the device name of the specified device.
        /// </summary>
        /// <param name="device">The device whose device name is to be validated.</param>
        /// <returns>
        /// Returns "(not present)" if the device name is null,
        /// "(empty)" if the device name is empty,
        /// "(Invalid length)" if the device name length exceeds 24 characters,
        /// "(Not supported characters)" if the device name contains unsupported characters,
        /// otherwise returns the device name.
        /// </returns>
        public static string ValidatedeviceName(Device device)
        {
            if (device.DevName == null)
            {
                return "(not present)";
            }
            if (string.IsNullOrEmpty(device.DevName))
            {
                return "(empty)";
            }
            if (device.DevName.Length > 24)
            {
                return "(Invalid length)";
            }
            if (Regex.IsMatch(device.DevName, @"^[a-zA-Z0-9\s]+$") == false)
            {
                return "(Not supported characters)";
            }
            return device.DevName;
        }

        /// <summary>
        /// Validates the model name of the specified device.
        /// </summary>
        /// <param name="device">The device whose model name is to be validated.</param>
        /// <returns>
        /// Returns "(not present)" if the model name is null,
        /// "(empty)" if the model name is empty,
        /// "(Invalid length)" if the model name length exceeds 24 characters,
        /// "(Not supported characters)" if the model name contains unsupported characters,
        /// otherwise returns the model name.
        /// </returns>
        public static string ValidateModelName(Device device)
        {
            if (device.ModelName == null)
            {
                return "(not present)";
            }
            if (string.IsNullOrEmpty(device.ModelName))
            {
                return "(empty)";
            }
            if (device.ModelName.Length > 24)
            {
                return "(Invalid length)";
            }
            if (Regex.IsMatch(device.ModelName, @"^[a-zA-Z0-9\s]+$") == false)
            {
                return "(Not supported characters)";
            }
            return device.ModelName;
        }

        /// <summary>
        /// Validates the type of the specified device.
        /// </summary>
        /// <param name="device">The device whose type is to be validated.</param>
        /// <returns>
        /// Returns "(not present)" if the device type is null,
        /// "(empty)" if the device type is empty,
        /// "(Not supported Format)" if the device type is not "A3" or "A4",
        /// otherwise returns the device type.
        /// </returns>
        public static string Validatetype(Device device)
        {
            if (device.Type == null)
            {
                return "(not present)";
            }
            if (string.IsNullOrEmpty(device.Type))
            {
                return "(empty)";
            }
            if ((device.Type == "A3" || device.Type == "A4") == false)
            {
                return "(Not supported Formate)";
            }
            return device.Type;
        }

        /// <summary>
        /// Validates the port number.
        /// </summary>
        /// <param name="PortNo">The port number to validate.</param>
        /// <returns>
        /// Returns "(not present)" if the port number is null,
        /// "(empty)" if the port number is empty,
        /// "(Not supported format)" if the port number does not consist of digits only,
        /// otherwise returns the port number.
        /// </returns>
        public static string ValidatePortNo(string PortNo)
        {
            if (PortNo == null)
            {
                return "(not present)";
            }
            if (string.IsNullOrEmpty(PortNo))
            {
                return "(empty)";
            }
            if (Regex.IsMatch(PortNo, @"^[0-9]+$") == false)
            {
                return "(Not supported formate)";
            }
            return PortNo;
        }

        /// <summary>
        /// Validates the SSL usage setting of the specified device.
        /// </summary>
        /// <param name="device">The device whose SSL usage setting is to be validated.</param>
        /// <returns>
        /// Returns "(not present)" if the SSL usage setting is null,
        /// "(empty)" if the SSL usage setting is empty,
        /// "(Not supported format)" if the SSL usage setting is not "true" or "false",
        /// otherwise returns the SSL usage setting.
        /// </returns>
        public static string ValidateUseSSl(Device device)
        {
            if (device.CommSetting.UseSSL == null)
            {
                return "(not present)";
            }
            if (string.IsNullOrEmpty(device.CommSetting.UseSSL))
            {
                return "(empty)";
            }
            if ((device.CommSetting.UseSSL == "false" || device.CommSetting.UseSSL == "true") == false)
            {
                return "(Not supported formate)";
            }
            return device.CommSetting.UseSSL;
        }

        /// <summary>
        /// Validates the password of the specified device.
        /// </summary>
        /// <param name="device">The device whose password is to be validated.</param>
        /// <returns>
        /// Returns "(not present)" if the password is null,
        /// "(empty)" if the password is empty,
        /// "(Invalid length)" if the password length exceeds 64 characters,
        /// otherwise returns the password.
        /// </returns>
        public static string ValidatePassword(Device device)
        {
            if (device.CommSetting.Password == null)
            {
                return "(not present)";
            }
            if (string.IsNullOrEmpty(device.CommSetting.Password))
            {
                return "(empty)";
            }
            if (device.CommSetting.Password.Length > 64)
            {
                return "(Invalid length)";
            }
            return device.CommSetting.Password;
        }
    }
}
